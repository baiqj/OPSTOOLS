#!/usr/bin/env python
#coding=utf8

REDIS = {
    'host': '192.168.10.242',
    'port': 6379,
    'base':   0,
    }

MYSQL = {
    'host': '192.168.10.241',
    'port': 3306,
    'user': 'dave',
    'pass': '12345ssdlh',
    'base': 'order_syn',
    'char': 'utf8',
    }
MAIL = {
    'mailfm':'ops_admin@11125.com',
    'passwd':'12345ssdlh',
    'toadds':['wangpengtao@11125.com', 'liuxinhua@11125.com'],
    }