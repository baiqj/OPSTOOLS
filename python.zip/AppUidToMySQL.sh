#!/bin/bash

cd /opt/ops/RedisToMySQL

python HashToMySQL.py appuid_syn open_appuid db_j_logs