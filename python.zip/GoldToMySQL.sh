#!/bin/bash

cd /opt/ops/RedisToMySQL

python HashToMySQL.py gold_syn usergold_log db_j_logs