#!/bin/bash

cd /opt/ops/RedisToMySQL

python HashToMySQL.py sms_syn sendsms_log db_j_logs